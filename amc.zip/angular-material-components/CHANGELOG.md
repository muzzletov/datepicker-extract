# Changelog
All notable changes to this library will be documented in this file.

## [2.0.0] - 2019-03-23
### Fixed
- Fix bugs ([#13](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/13), [#20](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/20), [#22](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/22, [#37](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/37), [#38](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/38), [#39](https://github.com/h2qutc/ngx-mat-datetime-picker/issues/39)).