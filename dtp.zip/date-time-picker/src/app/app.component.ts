import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {MatDatepickerInput, MatDatepickerToggle, MatTimeDatepicker} from "../datepicker";
import {provideNativeDateAdapter} from "@angular/material/core";
import {MatFormField, MatHint, MatLabel} from "@angular/material/form-field";
import {MatIcon} from "@angular/material/icon";
import {MatInput} from "@angular/material/input";
import {MatButton} from "@angular/material/button";

@Component({
  selector: 'app-root',
  standalone: true,
  providers: [provideNativeDateAdapter()],

  imports: [RouterOutlet, MatDatepickerInput, MatLabel, MatFormField, MatDatepickerToggle, MatIcon, MatInput, MatHint, MatButton, MatTimeDatepicker],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'date-time-picker';
}
