declare const ngDevMode: object | null;
