/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

import {NgModule} from '@angular/core';

import {MatTimeDatepicker} from './datepicker';
import {
  MAT_DATEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER,
} from './datepicker-base';
import {MatDatepickerIntl} from './datepicker-intl';


@NgModule({
  imports: [
    MatTimeDatepicker,

  ],
  exports: [
    MatTimeDatepicker,

  ],
  providers: [MatDatepickerIntl, MAT_DATEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER],
})
export class MatDatepickerModule {}
